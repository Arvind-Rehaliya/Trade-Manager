gui.wait
gui.notepad
gui.run
