package db_client;

public class EmptyFieldException extends Exception {
    
    public EmptyFieldException(String s){
        super(s);
    }
}
