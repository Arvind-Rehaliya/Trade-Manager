package gui;

import static gui.homePage.user_perm;
import db_client.SewingWorkerDetails;

public class Panel_SewingWorkerDetails extends javax.swing.JPanel {
    public SewingWorkerDetails sw;
    
    public Panel_SewingWorkerDetails() { 
        initComponents(); 
        sw = new SewingWorkerDetails();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        sp = new javax.swing.JScrollPane();
        Display = new javax.swing.JButton();
        ad = new javax.swing.JButton();

        org.openide.awt.Mnemonics.setLocalizedText(jLabel2, org.openide.util.NbBundle.getMessage(Panel_SewingWorkerDetails.class, "Panel_SewingWorkerDetails.jLabel2.text")); // NOI18N

        setBackground(new java.awt.Color(80, 80, 80));
        setPreferredSize(new java.awt.Dimension(953, 550));

        sp.setBorder(null);

        org.openide.awt.Mnemonics.setLocalizedText(Display, org.openide.util.NbBundle.getMessage(Panel_SewingWorkerDetails.class, "Panel_SewingWorkerDetails.Display.text")); // NOI18N
        Display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisplayActionPerformed(evt);
            }
        });

        ad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/res/back-24.png"))); // NOI18N
        org.openide.awt.Mnemonics.setLocalizedText(ad, org.openide.util.NbBundle.getMessage(Panel_SewingWorkerDetails.class, "Panel_SewingWorkerDetails.ad.text")); // NOI18N
        ad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(sp, javax.swing.GroupLayout.PREFERRED_SIZE, 841, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Display, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(539, 539, 539)
                        .addComponent(ad, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(55, 55, 55))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(sp, javax.swing.GroupLayout.PREFERRED_SIZE, 408, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Display, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ad, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void DisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisplayActionPerformed
        if(user_perm.charAt(0) == '0') sw.noRowDisplay();  else sw.display();
    }//GEN-LAST:event_DisplayActionPerformed

    private void adActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adActionPerformed
        sw.addData();
    }//GEN-LAST:event_adActionPerformed

    public SewingWorkerDetails get() {  return sw;  } 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Display;
    public javax.swing.JButton ad;
    private javax.swing.JLabel jLabel2;
    public static javax.swing.JScrollPane sp;
    // End of variables declaration//GEN-END:variables
}
